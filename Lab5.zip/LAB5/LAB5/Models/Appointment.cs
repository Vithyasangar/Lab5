﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAB5.Models
{
    public class Appointment
    {
        public int appointmentId { get; set; }
        public string appointmentType { get; set; }
        public DateTime appointmentDate { get; set; }

        public string employeefname { get; set; }
        public string customerfname { get; }
        public string customerlname { get; }
        public string employeelname { get; set; }
        public string fullname { get { return "(ID: " + this.employeeId + ") " + this.employeefname + " " + this.employeelname; } }
        public string customerfullname { get { return "(ID: " + this.customertId + ") " + this.customerfname + " " + this.customerlname; } }
        public int employeeId { get; set; }

        public virtual Employee Employee { get; set; }


        public int customertId { get; set; }
        public virtual Customer Customer { get; set; }


        public bool Validate(string appointmentType, string employeefname,string customerfname)
        {

            if (string.IsNullOrEmpty(appointmentType) || string.IsNullOrEmpty(employeefname) || string.IsNullOrEmpty(customerfname) || employeefname.Length < 2 || customerfname.Length < 2 )
            {

                return false;
            }
            else
            {
                return true;
            }


        }

    }
}
