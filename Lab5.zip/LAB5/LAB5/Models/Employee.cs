﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAB5.Models
{
    public class Employee
    {
        public int employeeId { get; set; }
        public string employeefname { get; set; }
        public string employeelname { get; set; }
        public string employeephone { get; set; }
        public string fullname { get { return "(ID: " + this.employeeId + ") " + this.employeefname + " " + this.employeelname; } }

        //Validation function
        public bool Validate(string employeefname, string employeelname, string phone)
        {
            Int64 numPhone;

            if (string.IsNullOrEmpty(employeefname) || string.IsNullOrEmpty(employeelname) || string.IsNullOrEmpty(phone) || employeefname.Length < 2 || employeelname.Length < 2 || phone.Length != 10 || Int64.TryParse(phone, out numPhone) == false)
            {

                return false;
            }
            else
            {
                return true;
            }


        }

    }
}
