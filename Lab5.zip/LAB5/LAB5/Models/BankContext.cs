﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace LAB5.Models
{
    public class BankContext : DbContext
    {
        public BankContext(DbContextOptions<BankContext> options) : base(options)
        {

        }

        public DbSet<Appointment> appointment { get; set; }
        public DbSet<Employee> employees { get; set; }
        public DbSet<Customer> customers { get; set; }
    }
}
