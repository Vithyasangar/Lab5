﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LAB5.Models;

namespace LAB5.Controllers
{
    public class AppointmentsController : Controller
    {
        private readonly BankContext _context;

        public AppointmentsController(BankContext context)
        {
            _context = context;
        }

        // GET: Appointments
        public async Task<IActionResult> Index()
        {
            var bankContext = _context.appointment.Include(a => a.Employee).Include(a => a.Customer);
            return View(await bankContext.ToListAsync());
        }

        // GET: Appointments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointment = await _context.appointment
                .Include(a => a.Employee)
                .Include(a => a.Customer)
                .FirstOrDefaultAsync(m => m.appointmentId == id);
            if (appointment == null)
            {
                return NotFound();
            }

            return View(appointment);
        }

        // GET: Appointments/Create
        public IActionResult Create()
        {
            ViewData["employeeId"] = new SelectList(_context.employees, "employeeId", "fullname");
            ViewData["customerId"] = new SelectList(_context.customers, "customerId", "customerfullname");
            return View();
        }

        // POST: Appointments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("appointmentId,appointmentType,appointmentDate,employeefname,employeelname,employeeId,customertId")] Appointment appointment)
        {
            //if the validation fails
            if (appointment.Validate(appointment.appointmentType,appointment.customerfname, appointment.customerlname) == false)
            {
                return View("Fail");
            }

            else
            {
                if (ModelState.IsValid)
                {
                    _context.Add(appointment);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                ViewData["employeeId"] = new SelectList(_context.employees, "employeeId", "fullname", appointment.employeeId);
                ViewData["customerId"] = new SelectList(_context.customers, "customerId", "customerfullname", appointment.customertId);
                return View(appointment);
            }
        }

        // GET: Appointments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointment = await _context.appointment.FindAsync(id);
            if (appointment == null)
            {
                return NotFound();
            }
            ViewData["employeeId"] = new SelectList(_context.employees, "employeeId", "fullname", appointment.employeeId);
            ViewData["customerId"] = new SelectList(_context.customers, "customerId", "customerfullname", appointment.customertId);
            return View(appointment);
        }

        // POST: Appointments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("appointmentId,appointmentType,appointmentDate,employeefname,employeelname,employeeId,customertId")] Appointment appointment)
        {
            if (id != appointment.appointmentId)
            {
                return NotFound();
            }

            if (appointment.Validate(appointment.appointmentType, appointment.customerfname, appointment.customerlname) == false)
            {
                return View("Fail");
            }

            else
            {

                if (ModelState.IsValid)
                {
                    try
                    {
                        _context.Update(appointment);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!AppointmentExists(appointment.appointmentId))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    return RedirectToAction(nameof(Index));
                }
            }
            ViewData["employeeId"] = new SelectList(_context.employees, "employeeId", "fullname", appointment.employeeId);
            ViewData["customerId"] = new SelectList(_context.customers, "customerId", "customerfullname", appointment.customertId);
            return View(appointment);
        }

        // GET: Appointments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var appointment = await _context.appointment
                .Include(a => a.Employee)
                .Include(a => a.Customer)
                .FirstOrDefaultAsync(m => m.appointmentId == id);
            if (appointment == null)
            {
                return NotFound();
            }

            return View(appointment);
        }

        // POST: Appointments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var appointment = await _context.appointment.FindAsync(id);
            _context.appointment.Remove(appointment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AppointmentExists(int id)
        {
            return _context.appointment.Any(e => e.appointmentId == id);
        }
    }
}
